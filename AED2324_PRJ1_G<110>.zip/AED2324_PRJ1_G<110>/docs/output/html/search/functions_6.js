var searchData=
[
  ['leaveucandclass_193',['leaveUCAndClass',['../classChange.html#a774a019ecce75716f0c30b588b083451',1,'Change']]],
  ['listofstudentsinatleastnucs_194',['listOfStudentsInAtLeastNUCs',['../classConsult.html#a4ffe098084f7daa6b61636aec75224b3',1,'Consult']]],
  ['listofstudentsinclass_195',['listOfStudentsInClass',['../classConsult.html#a4f9f004f23226b04b51878008bbc3690',1,'Consult']]],
  ['listofstudentsinuc_196',['listOfStudentsInUc',['../classConsult.html#a394fd829578e6975adc0f80e5d62f423',1,'Consult']]],
  ['listofstudentsinxbysortorder_197',['listOfStudentsInXBySortOrder',['../classConsult.html#ad387b3b6d654a51d3ee135c32ff8f8ab',1,'Consult']]],
  ['listofstudentsinyear_198',['listOfStudentsInYear',['../classConsult.html#a36785520e7327f9d72228092884d6124',1,'Consult']]],
  ['liststudentsbyname_199',['listStudentsByName',['../classConsult.html#a3caa287749e2005f82c0cae1a2da847d',1,'Consult']]]
];
