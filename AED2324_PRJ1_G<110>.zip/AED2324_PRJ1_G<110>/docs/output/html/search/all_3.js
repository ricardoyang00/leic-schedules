var searchData=
[
  ['extranotes_39',['extraNotes',['../structChangeLogEntry.html#a754b6b4a671462a17488ac10a11987d1',1,'ChangeLogEntry']]]
];
