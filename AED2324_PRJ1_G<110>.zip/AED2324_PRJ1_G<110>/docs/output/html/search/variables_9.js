var searchData=
[
  ['timestamp_265',['timestamp',['../structChangeLogEntry.html#a6b4a0eec6581e38f444f382e69ee23c6',1,'ChangeLogEntry']]],
  ['type_266',['Type',['../classSchedule.html#a22f4bb2f0857eb27e048d81e5fbb7fe1',1,'Schedule']]]
];
