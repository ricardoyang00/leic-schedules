var searchData=
[
  ['joinucclassrequest_140',['JoinUcClassRequest',['../structJoinUcClassRequest.html',1,'']]]
];
