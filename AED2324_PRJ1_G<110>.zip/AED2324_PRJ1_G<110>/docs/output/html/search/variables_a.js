var searchData=
[
  ['uccode_267',['ucCode',['../structSwapClassesRequest.html#ab5075b0dd19493e4dffd1ee45ebf8d6a',1,'SwapClassesRequest']]],
  ['uccode_268',['UcCode',['../classClass.html#a11f7cd6e47703bee8cfe1201a0c1ee57',1,'Class']]],
  ['uctoclasses_269',['UcToClasses',['../classSchedule.html#a8c6983ad5eeacec53005a67a95b94ecb',1,'Schedule::UcToClasses()'],['../classStudent.html#afb4db35e9349cf22023bc694e77dceaf',1,'Student::UcToClasses()']]]
];
