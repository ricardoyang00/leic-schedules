var searchData=
[
  ['newclasscode_250',['newClassCode',['../structChangeLogEntry.html#a95f88a952217da8d6be95dc632410f93',1,'ChangeLogEntry::newClassCode()'],['../structChangeClassRequest.html#a110a0bfdd2b1b818f4703c16b2a14b6c',1,'ChangeClassRequest::newClassCode()']]],
  ['newuccode_251',['newUcCode',['../structChangeLogEntry.html#a9f5fbf07e36a27c327cf55de83721727',1,'ChangeLogEntry::newUcCode()'],['../structChangeUcRequest.html#a014a8dab94b39c9a75a60cbe600ff407',1,'ChangeUcRequest::newUcCode()'],['../structJoinUcClassRequest.html#a5167d19f82573f0d3da008e23ccbed9b',1,'JoinUcClassRequest::newUcCode()']]]
];
