var searchData=
[
  ['joinucandclass_53',['joinUCAndClass',['../classChange.html#a31eaa9fb54db0125225cdcbf0d92c566',1,'Change']]],
  ['joinucclassrequest_54',['JoinUcClassRequest',['../structJoinUcClassRequest.html',1,'']]]
];
