var searchData=
[
  ['accepted_236',['accepted',['../structChangeLogEntry.html#acefe5cdf48eeb18ca4d5dd19c3911b9e',1,'ChangeLogEntry']]]
];
