var searchData=
[
  ['joinucandclass_192',['joinUCAndClass',['../classChange.html#a31eaa9fb54db0125225cdcbf0d92c566',1,'Change']]]
];
