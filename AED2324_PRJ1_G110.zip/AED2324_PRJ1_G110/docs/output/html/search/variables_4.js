var searchData=
[
  ['global_248',['global',['../classReadData.html#a3d4eb964007eea5265eaaa7ff23d3581',1,'ReadData']]]
];
