var searchData=
[
  ['leaveucclassrequest_141',['LeaveUcClassRequest',['../structLeaveUcClassRequest.html',1,'']]]
];
