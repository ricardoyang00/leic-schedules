var searchData=
[
  ['requestdata_252',['requestData',['../structChangeRequest.html#a59c41d31b6989d0fdc43a22988f94340',1,'ChangeRequest']]],
  ['requesttype_253',['requestType',['../structChangeLogEntry.html#a3ef0110b2af2ade998c8df206ad5fac7',1,'ChangeLogEntry::requestType()'],['../structChangeRequest.html#a55a7a0a015bb89d45d87e5fa12346a51',1,'ChangeRequest::requestType()']]],
  ['right_254',['right',['../structNode.html#a7328862eaa6dea28018326549b3294d3',1,'Node']]]
];
