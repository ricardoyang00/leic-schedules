var searchData=
[
  ['global_139',['Global',['../structGlobal.html',1,'']]]
];
