var searchData=
[
  ['insertstudent_52',['insertStudent',['../classStudentBST.html#a43fb76c2b83660b3687e8c9f09d90f65',1,'StudentBST']]]
];
