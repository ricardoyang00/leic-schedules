var indexSectionsWithContent =
{
  0: "acdefgijlmnoprstuw",
  1: "cgjlnrs",
  2: "cdrsu",
  3: "cdfgijlmnoprstu",
  4: "acdeglnrstuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

