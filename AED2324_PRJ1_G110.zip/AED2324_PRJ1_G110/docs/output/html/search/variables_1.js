var searchData=
[
  ['changelogs_237',['changeLogs',['../classScript.html#a08d7941d873a3538d3aa87bb9fb8a915',1,'Script']]],
  ['changerequestqueue_238',['changeRequestQueue',['../classScript.html#a1ae1defd37fd4ba91171e4dce1672dfb',1,'Script']]],
  ['classcode_239',['ClassCode',['../classClass.html#accbe67a88d88906cf1b56205c163f8c5',1,'Class']]],
  ['classcode1_240',['classCode1',['../structSwapClassesRequest.html#af764f5b1c1eedb663f531263827b0cca',1,'SwapClassesRequest']]],
  ['classcode2_241',['classCode2',['../structSwapClassesRequest.html#aa15a0c61a2f8ccba94823a45b2effe56',1,'SwapClassesRequest']]],
  ['classes_242',['Classes',['../structGlobal.html#a071d25965d6a9ae79d51301d1d6761bf',1,'Global']]],
  ['currentclasscode_243',['currentClassCode',['../structChangeLogEntry.html#a0af4e8d38e33a3ec2956ade6710c4560',1,'ChangeLogEntry::currentClassCode()'],['../structChangeClassRequest.html#ac595933b91f153b47e3a4d30cfb2e74c',1,'ChangeClassRequest::currentClassCode()'],['../structChangeUcRequest.html#ac743f258cc5932ec70332dd7db3889ad',1,'ChangeUcRequest::currentClassCode()'],['../structLeaveUcClassRequest.html#aed5fd0d6f8eb29e760afd9f08a1a11b5',1,'LeaveUcClassRequest::currentClassCode()']]],
  ['currentuccode_244',['currentUcCode',['../structChangeLogEntry.html#a81b7ff2dceaae8a764cc5dd6615906e6',1,'ChangeLogEntry::currentUcCode()'],['../structChangeClassRequest.html#ab14b55d97a19355b19a6537b6dd68261',1,'ChangeClassRequest::currentUcCode()'],['../structChangeUcRequest.html#ae1f2c7d9d0ef0283d1d0527c0e25c479',1,'ChangeUcRequest::currentUcCode()'],['../structLeaveUcClassRequest.html#a32b8fea1cc6e4b12d93f3d77418c5246',1,'LeaveUcClassRequest::currentUcCode()']]]
];
