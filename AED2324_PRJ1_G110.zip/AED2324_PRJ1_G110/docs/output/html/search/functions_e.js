var searchData=
[
  ['undoaction_234',['undoAction',['../classSystem.html#ac85cda89338f69fa40a96f86c36f4af9',1,'System']]],
  ['updatedata_235',['updateData',['../classConsult.html#a60c71cb1e45be5db7414cb4aad119390',1,'Consult::updateData()'],['../classSystem.html#a89d86d12fbbaf012ca1a9812d16025ea',1,'System::updateData()']]]
];
