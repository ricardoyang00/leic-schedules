var searchData=
[
  ['schedules_255',['Schedules',['../structGlobal.html#a4db93fdc1c319518606c03704b718295',1,'Global']]],
  ['starthour_256',['StartHour',['../classSchedule.html#adede150376db73b79d7e4e4d4423a4f5',1,'Schedule']]],
  ['student_257',['student',['../structChangeClassRequest.html#a5a24446275c9e4e4988ceba50e3851ff',1,'ChangeClassRequest::student()'],['../structChangeUcRequest.html#a9da806767bee5c170ffe61d8ae9d1c73',1,'ChangeUcRequest::student()'],['../structLeaveUcClassRequest.html#a663e3406f8c60f2f74f3eddd322891ee',1,'LeaveUcClassRequest::student()'],['../structJoinUcClassRequest.html#ac9ffce13e8c30f9e14ae1b9e7762dd0c',1,'JoinUcClassRequest::student()']]],
  ['student1_258',['student1',['../structSwapClassesRequest.html#abfdcb8aebcfa54f9e383288259a93b24',1,'SwapClassesRequest']]],
  ['student2_259',['student2',['../structSwapClassesRequest.html#a663aa68523ed623fd33ec2c7bff2e84b',1,'SwapClassesRequest']]],
  ['studentcode_260',['studentCode',['../structChangeLogEntry.html#a011e14444a14294f52a244c54c1f9669',1,'ChangeLogEntry']]],
  ['studentcode_261',['StudentCode',['../classStudent.html#a3b34b4dc725109f1e4cab86d819f72be',1,'Student']]],
  ['studentname_262',['StudentName',['../classStudent.html#ace2ca1d4f48c09efb1fefd79a71168be',1,'Student']]],
  ['studentname_263',['studentName',['../structChangeLogEntry.html#a3064b57e0ff915fe57e2aa510de5c466',1,'ChangeLogEntry']]],
  ['students_264',['Students',['../structGlobal.html#aa3593a2c21779c03668b1c0dbca58c81',1,'Global']]]
];
